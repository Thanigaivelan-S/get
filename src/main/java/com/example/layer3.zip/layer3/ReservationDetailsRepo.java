package com.example.layer3;

public interface ReservationDetailsRepo {

}
