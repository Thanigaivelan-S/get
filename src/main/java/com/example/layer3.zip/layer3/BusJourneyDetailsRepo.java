package com.example.layer3;

import com.example.layer2.BusJourneyDetails;

public interface BusJourneyDetailsRepo {
	void updateAvailableSeats(int busNo, int seatcounts);
}
