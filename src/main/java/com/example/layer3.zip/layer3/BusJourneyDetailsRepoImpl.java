package com.example.layer3;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.layer2.BusJourneyDetails;

@Repository
public class BusJourneyDetailsRepoImpl extends BaseRepository implements BusJourneyDetailsRepo {

	@Transactional
	public void updateAvailableSeats(int busNo, int seatsCount) {
		EntityManager entityManager = getEntityManager();
		BusJourneyDetails foundBus = entityManager.find(BusJourneyDetails.class,busNo);
		if(foundBus!=null) {
			
		}
		
	}

}
