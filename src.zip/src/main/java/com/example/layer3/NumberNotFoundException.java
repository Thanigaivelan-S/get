package com.example.layer3;

public class NumberNotFoundException extends Exception {
	public NumberNotFoundException(String str) {
		super(str);
	}
}
