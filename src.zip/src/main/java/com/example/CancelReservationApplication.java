package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CancelReservationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CancelReservationApplication.class, args);
	}

}
